import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'register_screen.dart';
import 'student_dashboard.dart';
import 'admin_dashboard.dart';



class LoginScreen extends StatefulWidget {

  const LoginScreen({super.key});


  @override
  State<LoginScreen> createState() => _LoginScreenState();

}





class _LoginScreenState extends State<LoginScreen> {


  final FirebaseAuth auth =
      FirebaseAuth.instance;



  final emailController =
  TextEditingController();



  final passwordController =
  TextEditingController();



  bool hidePassword = true;

  bool loading = false;





  Future<void> loginUser() async {


    if(emailController.text.trim().isEmpty ||
        passwordController.text.trim().isEmpty){


      ScaffoldMessenger.of(context).showSnackBar(

        const SnackBar(

          content:
          Text("Enter email and password"),

        ),

      );


      return;

    }




    try{


      setState(() {

        loading = true;

      });




      // Firebase Authentication Login

      UserCredential credential =
      await auth.signInWithEmailAndPassword(

        email:
        emailController.text.trim(),


        password:
        passwordController.text.trim(),

      );




      String uid =
          credential.user!.uid;




      // Get User Data From Firestore

      DocumentSnapshot doc =
      await FirebaseFirestore.instance
          .collection("users")
          .doc(uid)
          .get();





      if(!doc.exists){


        ScaffoldMessenger.of(context).showSnackBar(

          const SnackBar(

            content:
            Text(
                "Firestore user data not found"
            ),

          ),

        );


        return;

      }






      Map<String,dynamic> data =
      doc.data() as Map<String,dynamic>;





      String role =
          data["role"] ?? "Student";



      role =
          role.toLowerCase();






      if(role == "admin"){



        Navigator.pushReplacement(

          context,

          MaterialPageRoute(

            builder:(_)=>
            const AdminDashboard(),

          ),

        );



      }

      else{



        Navigator.pushReplacement(

          context,

          MaterialPageRoute(

            builder:(_)=>
            const StudentDashboard(),

          ),

        );



      }





    }


    on FirebaseAuthException catch(e){


      String message =
          "Login Failed";



      if(e.code ==
          "user-not-found"){

        message =
        "User not found";


      }

      else if(e.code ==
          "wrong-password"){

        message =
        "Wrong password";


      }

      else if(e.code ==
          "invalid-email"){

        message =
        "Invalid email";


      }




      ScaffoldMessenger.of(context).showSnackBar(

        SnackBar(

          content:
          Text(message),

        ),

      );


    }



    finally{


      setState(() {

        loading = false;

      });


    }



  }







  @override
  Widget build(BuildContext context) {


    return Scaffold(


      body: SafeArea(


        child: SingleChildScrollView(


          padding:
          const EdgeInsets.all(24),



          child: Column(


            children:[



              const SizedBox(height:60),




              const Icon(

                Icons.school,

                size:90,

                color:Colors.blue,

              ),





              const SizedBox(height:20),




              const Text(

                "SmartUni Companion",

                style:

                TextStyle(

                  fontSize:28,

                  fontWeight:FontWeight.bold,

                ),

              ),




              const SizedBox(height:40),





              TextField(

                controller:
                emailController,


                decoration:

                const InputDecoration(

                  labelText:"Email",

                  prefixIcon:
                  Icon(Icons.email),

                  border:
                  OutlineInputBorder(),

                ),

              ),





              const SizedBox(height:20),





              TextField(

                controller:
                passwordController,


                obscureText:
                hidePassword,



                decoration:

                InputDecoration(

                  labelText:"Password",


                  prefixIcon:
                  const Icon(Icons.lock),



                  suffixIcon:

                  IconButton(

                    icon:

                    Icon(

                      hidePassword

                          ?

                      Icons.visibility_off

                          :

                      Icons.visibility,

                    ),


                    onPressed:(){

                      setState(() {

                        hidePassword =
                        !hidePassword;

                      });


                    },


                  ),



                  border:
                  const OutlineInputBorder(),


                ),


              ),






              const SizedBox(height:30),






              SizedBox(

                width:
                double.infinity,


                height:50,


                child:

                ElevatedButton(



                  onPressed:

                  loading
                      ?
                  null
                      :
                  loginUser,



                  child:

                  loading

                      ?

                  const CircularProgressIndicator()

                      :

                  const Text("Login"),


                ),

              ),





              const SizedBox(height:20),





              Row(

                mainAxisAlignment:
                MainAxisAlignment.center,


                children:[



                  const Text(
                      "Don't have an account?"
                  ),




                  TextButton(

                    onPressed:(){


                      Navigator.push(

                        context,

                        MaterialPageRoute(

                          builder:(_)=>
                          const RegisterScreen(),

                        ),

                      );


                    },


                    child:

                    const Text(
                        "Register"
                    ),

                  )


                ],

              )




            ],

          ),


        ),


      ),


    );


  }






  @override
  void dispose(){


    emailController.dispose();

    passwordController.dispose();


    super.dispose();


  }



}