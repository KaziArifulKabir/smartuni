import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class RegisterScreen extends StatefulWidget {

  const RegisterScreen({super.key});


  @override
  State<RegisterScreen> createState() =>
      _RegisterScreenState();

}



class _RegisterScreenState extends State<RegisterScreen> {


  final FirebaseAuth auth =
      FirebaseAuth.instance;


  final FirebaseFirestore firestore =
      FirebaseFirestore.instance;



  final nameController =
  TextEditingController();

  final universityIdController =
  TextEditingController();

  final emailController =
  TextEditingController();

  final passwordController =
  TextEditingController();

  final phoneController =
  TextEditingController();

  final bloodController =
  TextEditingController();

  final batchController =
  TextEditingController();

  final sectionController =
  TextEditingController();



  String? selectedDepartment;

  String? selectedSemester;


  bool loading = false;



  final departments = [

    "Computer Science & Engineering",
    "Business Administration",
    "Electrical Engineering",

  ];



  final semesters = [

    "1st Semester",
    "2nd Semester",
    "3rd Semester",
    "4th Semester",
    "5th Semester",
    "6th Semester",
    "7th Semester",
    "8th Semester",

  ];





  Future<void> registerUser() async {


    if(
    nameController.text.trim().isEmpty ||
        universityIdController.text.trim().isEmpty ||
        emailController.text.trim().isEmpty ||
        passwordController.text.trim().isEmpty ||
        selectedDepartment == null ||
        selectedSemester == null
    ){

      ScaffoldMessenger.of(context)
          .showSnackBar(

        const SnackBar(

          content:
          Text(
              "Please fill all required fields"
          ),

        ),

      );

      return;

    }



    try{


      setState(() {

        loading = true;

      });



      UserCredential userCredential =
      await auth.createUserWithEmailAndPassword(

        email:
        emailController.text.trim(),

        password:
        passwordController.text.trim(),

      );



      String uid =
          userCredential.user!.uid;



      await firestore
          .collection("users")
          .doc(uid)
          .set({

        "user_id":
        uid,


        "university_id":
        universityIdController.text.trim(),


        "name":
        nameController.text.trim(),


        "email":
        emailController.text.trim(),


        "phone":
        phoneController.text.trim(),


        "blood_group":
        bloodController.text.trim(),


        "department":
        selectedDepartment,


        "semester":
        selectedSemester,


        "batch":
        batchController.text.trim(),


        "section":
        sectionController.text.trim(),


        "role":
        "Student",


        "created_at":
        FieldValue.serverTimestamp(),


      });



      ScaffoldMessenger.of(context)
          .showSnackBar(

        const SnackBar(

          content:
          Text(
              "Registration Successful"
          ),

        ),

      );



      Navigator.pop(context);



    }

    on FirebaseAuthException catch(e){


      ScaffoldMessenger.of(context)
          .showSnackBar(

        SnackBar(

          content:
          Text(
              e.message ??
                  "Registration Failed"
          ),

        ),

      );


    }


    finally{


      setState(() {

        loading = false;

      });


    }


  }







  @override
  Widget build(BuildContext context) {


    return Scaffold(


      appBar:
      AppBar(

        title:
        const Text(
            "Create Account"
        ),

      ),



      body:

      SingleChildScrollView(


        padding:
        const EdgeInsets.all(20),


        child:

        Column(

          children: [



            const CircleAvatar(

              radius:45,

              child:
              Icon(

                Icons.person,

                size:50,

              ),

            ),



            const SizedBox(
                height:25
            ),



            buildField(
                nameController,
                "Full Name",
                Icons.person
            ),



            buildField(
                universityIdController,
                "University ID",
                Icons.badge
            ),



            buildField(
                emailController,
                "Email",
                Icons.email
            ),



            buildField(
                passwordController,
                "Password",
                Icons.lock,
                password:true
            ),



            buildField(
                phoneController,
                "Phone",
                Icons.phone
            ),



            buildField(
                bloodController,
                "Blood Group",
                Icons.bloodtype
            ),




            DropdownButtonFormField<String>(


              value:
              selectedDepartment,


              decoration:
              const InputDecoration(

                labelText:
                "Department",

                border:
                OutlineInputBorder(),

              ),


              items:

              departments.map(

                      (e)=>

                      DropdownMenuItem(

                        value:e,

                        child:
                        Text(e),

                      )

              ).toList(),



              onChanged:(value){


                setState(() {

                  selectedDepartment=value;

                });


              },

            ),



            const SizedBox(height:15),




            DropdownButtonFormField<String>(


              value:
              selectedSemester,


              decoration:
              const InputDecoration(

                labelText:
                "Semester",

                border:
                OutlineInputBorder(),

              ),


              items:

              semesters.map(

                      (e)=>

                      DropdownMenuItem(

                        value:e,

                        child:
                        Text(e),

                      )

              ).toList(),



              onChanged:(value){


                setState(() {

                  selectedSemester=value;

                });


              },


            ),



            const SizedBox(height:15),



            buildField(
                batchController,
                "Batch",
                Icons.groups
            ),



            buildField(
                sectionController,
                "Section",
                Icons.class_
            ),



            const SizedBox(height:25),




            SizedBox(

              width:
              double.infinity,


              height:
              50,


              child:

              ElevatedButton(


                onPressed:
                loading
                    ? null
                    : registerUser,


                child:

                loading

                    ?

                const CircularProgressIndicator()

                    :

                const Text(
                    "Register"
                ),


              ),

            )



          ],

        ),

      ),


    );


  }





  Widget buildField(

      TextEditingController controller,

      String label,

      IconData icon,

      {bool password=false}

      ){

    return Padding(

      padding:
      const EdgeInsets.only(bottom:15),


      child:

      TextField(

        controller:
        controller,


        obscureText:
        password,


        decoration:

        InputDecoration(

          labelText:
          label,


          prefixIcon:
          Icon(icon),


          border:
          const OutlineInputBorder(),


        ),


      ),

    );


  }






  @override
  void dispose(){


    nameController.dispose();

    universityIdController.dispose();

    emailController.dispose();

    passwordController.dispose();

    phoneController.dispose();

    bloodController.dispose();

    batchController.dispose();

    sectionController.dispose();


    super.dispose();

  }



}