
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ProfileScreen extends StatelessWidget {
const ProfileScreen({super.key});

@override
Widget build(BuildContext context) {
final User? currentUser = FirebaseAuth.instance.currentUser;

return Scaffold(
backgroundColor: const Color(0xffF5F7FB),

appBar: AppBar(
backgroundColor: const Color(0xff1565C0),
foregroundColor: Colors.white,
elevation: 0,

title: const Text(
"My Profile",
style: TextStyle(
fontWeight: FontWeight.bold,
),
),
),

body: currentUser == null
? const Center(
child: Text(
"User not logged in",
style: TextStyle(
fontSize: 16,
),
),
)
    : FutureBuilder<DocumentSnapshot>(
future: FirebaseFirestore.instance
    .collection("users")
    .doc(currentUser.uid)
    .get(),

builder: (context, snapshot) {
// Loading
if (snapshot.connectionState ==
ConnectionState.waiting) {
return const Center(
child: CircularProgressIndicator(),
);
}

// Error
if (snapshot.hasError) {
return Center(
child: Text(
"Error: ${snapshot.error}",
textAlign: TextAlign.center,
),
);
}

// Data not found
if (!snapshot.hasData ||
!snapshot.data!.exists) {
return const Center(
child: Text(
"Profile data not found",
style: TextStyle(
fontSize: 16,
),
),
);
}

final Map<String, dynamic> data =
snapshot.data!.data()
as Map<String, dynamic>;

final String name =
data["name"]?.toString() ?? "Student";

  final String universityId =
      data["university_id"]?.toString() ?? "";

final String email =
data["email"]?.toString() ?? "";

final String phone =
data["phone"]?.toString() ?? "";

final String department =
data["department"]?.toString() ?? "";

final String semester =
data["semester"]?.toString() ?? "";

final String batch =
data["batch"]?.toString() ?? "";

final String section =
data["section"]?.toString() ?? "";

final String bloodGroup =
data["blood_group"]?.toString() ?? "";

final String firstLetter =
name.trim().isNotEmpty
? name.trim()[0].toUpperCase()
    : "S";

return SingleChildScrollView(
physics:
const BouncingScrollPhysics(),

child: Column(
children: [

// ==================================================
// PROFILE HEADER
// ==================================================

Container(
width: double.infinity,

padding: const EdgeInsets.fromLTRB(
20,
25,
20,
30,
),

decoration: const BoxDecoration(
color: Color(0xff1565C0),

borderRadius: BorderRadius.only(
bottomLeft: Radius.circular(30),
bottomRight: Radius.circular(30),
),
),

child: Column(
children: [

// Profile Picture
Container(
width: 105,
height: 105,

decoration: BoxDecoration(
color: Colors.white,
shape: BoxShape.circle,

boxShadow: [
BoxShadow(
color: Colors.black26,
blurRadius: 10,
offset: Offset(0, 4),
),
],
),

child: CircleAvatar(
radius: 48,
backgroundColor:
const Color(0xffE3F2FD),

child: Text(
firstLetter,

style: const TextStyle(
fontSize: 42,
fontWeight:
FontWeight.bold,
color:
Color(0xff1565C0),
),
),
),
),

const SizedBox(height: 15),

// Student Name
Text(
name,

textAlign: TextAlign.center,

style: const TextStyle(
color: Colors.white,
fontSize: 24,
fontWeight: FontWeight.bold,
),
),

const SizedBox(height: 6),

// Student ID
  if (universityId.isNotEmpty)
    Text(
      "University ID: $universityId",

style: const TextStyle(
color: Colors.white70,
fontSize: 15,
),
),

const SizedBox(height: 15),

// Department / Semester / Batch
Wrap(
alignment: WrapAlignment.center,

spacing: 8,
runSpacing: 8,

children: [

if (department.isNotEmpty)
profileChip(
Icons.school,
department,
),

if (semester.isNotEmpty)
profileChip(
Icons.menu_book,
semester,
),

if (batch.isNotEmpty)
profileChip(
Icons.groups,
"Batch $batch",
),
],
),
],
),
),

const SizedBox(height: 25),

// ==================================================
// PERSONAL INFORMATION
// ==================================================

const Padding(
padding:
EdgeInsets.symmetric(horizontal: 20),

child: Align(
alignment: Alignment.centerLeft,

child: Text(
"Personal Information",

style: TextStyle(
fontSize: 20,
fontWeight: FontWeight.bold,
color: Color(0xff1E293B),
),
),
),
),

const SizedBox(height: 14),

Padding(
padding:
const EdgeInsets.symmetric(horizontal: 20),

child: Column(
children: [

infoCard(
icon: Icons.email_rounded,
title: "Email",
value: email,
),

infoCard(
icon: Icons.phone_rounded,
title: "Phone",
value: phone,
),

infoCard(
icon: Icons.bloodtype_rounded,
title: "Blood Group",
value: bloodGroup,
),
],
),
),

const SizedBox(height: 20),

// ==================================================
// ACADEMIC INFORMATION
// ==================================================

const Padding(
padding:
EdgeInsets.symmetric(horizontal: 20),

child: Align(
alignment: Alignment.centerLeft,

child: Text(
"Academic Information",

style: TextStyle(
fontSize: 20,
fontWeight: FontWeight.bold,
color: Color(0xff1E293B),
),
),
),
),

const SizedBox(height: 14),

Padding(
padding:
const EdgeInsets.symmetric(horizontal: 20),

child: Column(
children: [

  infoCard(
    icon: Icons.badge_rounded,
    title: "University ID",
    value: universityId,
  ),

infoCard(
icon: Icons.school_rounded,
title: "Department",
value: department,
),

infoCard(
icon:
Icons.calendar_month_rounded,
title: "Semester",
value: semester,
),

infoCard(
icon: Icons.groups_rounded,
title: "Batch",
value: batch,
),

infoCard(
icon: Icons.class_rounded,
title: "Section",
value: section,
),
],
),
),

const SizedBox(height: 30),
],
),
);
},
),
);
}

// ==============================================================
// PROFILE CHIP
// ==============================================================

Widget profileChip(
IconData icon,
String text,
) {
return Container(
padding: const EdgeInsets.symmetric(
horizontal: 12,
vertical: 8,
),

decoration: BoxDecoration(
color: Colors.white.withOpacity(0.15),
borderRadius: BorderRadius.circular(20),
),

child: Row(
mainAxisSize: MainAxisSize.min,

children: [

Icon(
icon,
size: 15,
color: Colors.white,
),

const SizedBox(width: 6),

Text(
text,

style: const TextStyle(
color: Colors.white,
fontSize: 12,
fontWeight: FontWeight.w500,
),
),
],
),
);
}

// ==============================================================
// INFORMATION CARD
// ==============================================================

Widget infoCard({
required IconData icon,
required String title,
required String value,
}) {
return Container(
width: double.infinity,

margin: const EdgeInsets.only(bottom: 12),

padding: const EdgeInsets.all(15),

decoration: BoxDecoration(
color: Colors.white,

borderRadius: BorderRadius.circular(18),

boxShadow: [
BoxShadow(
color: Colors.black.withOpacity(0.04),
blurRadius: 8,
offset: const Offset(0, 3),
),
],
),

child: Row(
children: [

Container(
width: 45,
height: 45,

decoration: BoxDecoration(
color: const Color(0xffE3F2FD),
borderRadius: BorderRadius.circular(13),
),

child: Icon(
icon,
color: const Color(0xff1565C0),
size: 22,
),
),

const SizedBox(width: 13),

Expanded(
child: Column(
crossAxisAlignment:
CrossAxisAlignment.start,

children: [

Text(
title,

style: const TextStyle(
fontSize: 12,
color: Colors.grey,
),
),

const SizedBox(height: 4),

Text(
value.isNotEmpty
? value
    : "Not provided",

maxLines: 2,

overflow:
TextOverflow.ellipsis,

style: const TextStyle(
fontSize: 15,
fontWeight: FontWeight.w600,
color: Color(0xff1E293B),
),
),
],
),
),
],
),
);
}
}
