import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class ProfileScreen extends StatelessWidget {

  const ProfileScreen({super.key});


  @override
  Widget build(BuildContext context) {


    User? currentUser =
        FirebaseAuth.instance.currentUser;



    return Scaffold(

      appBar: AppBar(

        title:
        const Text(
          "Student Profile",
        ),

      ),



      body:

      currentUser == null

          ?

      const Center(

        child:
        Text(
          "User not logged in",
        ),

      )


          :

      FutureBuilder<DocumentSnapshot>(


        future:

        FirebaseFirestore.instance

            .collection("users")

            .doc(currentUser.uid)

            .get(),



        builder:(context, snapshot){



          if(snapshot.connectionState ==
              ConnectionState.waiting){


            return const Center(

              child:
              CircularProgressIndicator(),

            );

          }




          if(!snapshot.hasData ||
              !snapshot.data!.exists){


            return const Center(

              child:
              Text(
                "Profile data not found",
              ),

            );

          }



          Map<String,dynamic> data =

          snapshot.data!.data()
          as Map<String,dynamic>;



          return SingleChildScrollView(


            padding:
            const EdgeInsets.all(20),



            child:
            Column(


              children:[



                const CircleAvatar(

                  radius:55,

                  child:
                  Icon(

                    Icons.person,

                    size:65,

                  ),

                ),



                const SizedBox(height:20),




                Text(

                  data["name"] ?? "No Name",

                  style:
                  const TextStyle(

                    fontSize:25,

                    fontWeight:
                    FontWeight.bold,

                  ),

                ),




                const SizedBox(height:5),




                Text(

                  data["student_id"] ?? "",

                  style:
                  const TextStyle(

                    color:
                    Colors.grey,

                    fontSize:16,

                  ),

                ),




                const SizedBox(height:30),




                profileCard(

                  Icons.email,

                  "Email",

                  data["email"] ?? "",

                ),



                profileCard(

                  Icons.phone,

                  "Phone",

                  data["phone"] ?? "",

                ),



                profileCard(

                  Icons.school,

                  "Department",

                  data["department"] ?? "",

                ),



                profileCard(

                  Icons.calendar_month,

                  "Semester",

                  data["semester"] ?? "",

                ),



                profileCard(

                  Icons.groups,

                  "Batch",

                  data["batch"] ?? "",

                ),



                profileCard(

                  Icons.class_,

                  "Section",

                  data["section"] ?? "",

                ),



                profileCard(

                  Icons.bloodtype,

                  "Blood Group",

                  data["blood_group"] ?? "",

                ),



              ],

            ),

          );


        },

      ),


    );


  }





  Widget profileCard(

      IconData icon,

      String title,

      String value,

      ){


    return Card(

      margin:
      const EdgeInsets.only(
        bottom:12,
      ),


      child:
      ListTile(

        leading:
        CircleAvatar(

          child:
          Icon(icon),

        ),


        title:
        Text(

          title,

          style:
          const TextStyle(

            fontWeight:
            FontWeight.bold,

          ),

        ),


        subtitle:
        Text(value),


      ),

    );


  }


}