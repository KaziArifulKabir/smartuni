import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'profile_screen.dart';
import 'courses_screen.dart';
import 'notice_screen.dart';
import 'login_screen.dart';


class StudentDashboard extends StatelessWidget {

  const StudentDashboard({super.key});


  @override
  Widget build(BuildContext context) {


    User? currentUser =
        FirebaseAuth.instance.currentUser;


    if(currentUser == null){

      return const LoginScreen();

    }



    return Scaffold(

      appBar: AppBar(

        title: const Text(
          "SmartUni Companion",
        ),


        actions: [

          IconButton(

            icon: const Icon(
              Icons.logout,
            ),


            onPressed: () async{


              await FirebaseAuth.instance.signOut();


              Navigator.pushAndRemoveUntil(

                context,

                MaterialPageRoute(

                  builder: (_) =>
                  const LoginScreen(),

                ),

                    (route)=>false,

              );


            },

          )

        ],

      ),



      body: StreamBuilder<DocumentSnapshot>(


        stream:

        FirebaseFirestore.instance
            .collection("users")
            .doc(currentUser.uid)
            .snapshots(),



        builder:(context,snapshot){


          if(snapshot.connectionState ==
              ConnectionState.waiting){

            return const Center(
              child: CircularProgressIndicator(),
            );

          }



          if(!snapshot.hasData ||
              !snapshot.data!.exists){

            return const Center(
              child: Text(
                "User data not found",
              ),
            );

          }



          final data =
          snapshot.data!.data()
          as Map<String,dynamic>;



          return SingleChildScrollView(

            padding:
            const EdgeInsets.all(20),


            child: Column(

              crossAxisAlignment:
              CrossAxisAlignment.start,


              children:[



                // Student Information


                Container(

                  width:
                  double.infinity,


                  padding:
                  const EdgeInsets.all(20),


                  decoration:
                  BoxDecoration(

                    borderRadius:
                    BorderRadius.circular(20),


                    gradient:
                    const LinearGradient(

                      colors:[

                        Color(0xff1565C0),

                        Color(0xff42A5F5),

                      ],

                    ),

                  ),



                  child: Column(

                    crossAxisAlignment:
                    CrossAxisAlignment.start,


                    children:[


                      Text(

                        "Hello, ${data['name']} 👋",

                        style:
                        const TextStyle(

                          color: Colors.white,

                          fontSize:22,

                          fontWeight:
                          FontWeight.bold,

                        ),

                      ),


                      const SizedBox(height:15),



                      Text(

                        data['department'] ?? "",

                        style:
                        const TextStyle(

                          color: Colors.white,

                        ),

                      ),



                      const SizedBox(height:8),



                      Text(

                        data['semester'] ?? "",

                        style:
                        const TextStyle(

                          color: Colors.white,

                        ),

                      ),



                      const SizedBox(height:8),



                      Text(

                        "Batch: ${data['batch'] ?? ''}",

                        style:
                        const TextStyle(

                          color: Colors.white,

                        ),

                      ),


                    ],

                  ),

                ),



                const SizedBox(height:30),



                const Text(

                  "Quick Access",

                  style:
                  TextStyle(

                    fontSize:22,

                    fontWeight:
                    FontWeight.bold,

                  ),

                ),



                const SizedBox(height:15),



                GridView.count(

                  shrinkWrap:true,

                  physics:
                  const NeverScrollableScrollPhysics(),


                  crossAxisCount:2,


                  crossAxisSpacing:15,

                  mainAxisSpacing:15,


                  children:[


                    dashboardCard(

                      context,

                      Icons.person,

                      "Profile",

                      const ProfileScreen(),

                    ),



                    dashboardCard(

                      context,

                      Icons.book,

                      "Courses",

                      const CoursesScreen(),

                    ),



                    dashboardCard(

                      context,

                      Icons.notifications,

                      "Notices",

                      const NoticeScreen(),

                    ),


                  ],

                ),



                const SizedBox(height:30),



                const Text(

                  "Recent Notice",

                  style:
                  TextStyle(

                    fontSize:22,

                    fontWeight:
                    FontWeight.bold,

                  ),

                ),



                const SizedBox(height:15),



                StreamBuilder<QuerySnapshot>(

                  stream: FirebaseFirestore.instance
                      .collection("notices")
                      .orderBy(
                    "date",
                    descending: true,
                  )
                      .limit(3)
                      .snapshots(),


                  builder: (context, noticeSnapshot){


                    if(noticeSnapshot.connectionState ==
                        ConnectionState.waiting){

                      return const Center(

                        child:
                        CircularProgressIndicator(),

                      );

                    }



                    if(!noticeSnapshot.hasData ||
                        noticeSnapshot.data!.docs.isEmpty){


                      return const Card(

                        child: ListTile(

                          leading:
                          Icon(

                            Icons.campaign,

                            color: Colors.blue,

                          ),


                          title:
                          Text(
                            "No new notice",
                          ),


                          subtitle:
                          Text(
                            "Admin notices will appear here",
                          ),

                        ),

                      );


                    }




                    return Column(


                      children:

                      noticeSnapshot.data!.docs.map((doc){



                        final notice =
                        doc.data()
                        as Map<String,dynamic>;



                        return Card(

                          margin:
                          const EdgeInsets.only(
                            bottom:12,
                          ),


                          child: ListTile(


                            leading:
                            const Icon(

                              Icons.campaign,

                              color: Colors.blue,

                            ),



                            title:

                            Text(

                              notice["title"] ?? "",


                              style:
                              const TextStyle(

                                fontWeight:
                                FontWeight.bold,

                              ),

                            ),



                            subtitle:

                            Text(

                              notice["description"] ?? "",

                            ),


                          ),

                        );



                      }).toList(),


                    );


                  },


                )



              ],

            ),

          );


        },


      ),

    );

  }




  Widget dashboardCard(

      BuildContext context,

      IconData icon,

      String title,

      Widget page,

      ){


    return InkWell(

      borderRadius:
      BorderRadius.circular(20),


      onTap:(){


        Navigator.push(

          context,

          MaterialPageRoute(

            builder:(_)=>page,

          ),

        );


      },


      child: Container(


        decoration:

        BoxDecoration(

          color:Colors.white,


          borderRadius:
          BorderRadius.circular(20),


          boxShadow:[

            const BoxShadow(

              color:Colors.black12,

              blurRadius:8,

            )

          ],


        ),



        child:Column(

          mainAxisAlignment:
          MainAxisAlignment.center,


          children:[


            Icon(

              icon,

              size:45,

              color:Colors.blue,

            ),



            const SizedBox(height:10),



            Text(

              title,

              style:
              const TextStyle(

                fontWeight:
                FontWeight.bold,

              ),

            )


          ],

        ),

      ),

    );


  }


}