import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class NoticeScreen extends StatelessWidget {

  const NoticeScreen({super.key});


  @override
  Widget build(BuildContext context) {


    return Scaffold(


      appBar: AppBar(

        title: const Text(
          "Notices",
        ),

      ),



      body: StreamBuilder<QuerySnapshot>(



        stream:

        FirebaseFirestore.instance

            .collection("notices")

            .snapshots(),




        builder:(context, snapshot){



          if(snapshot.connectionState ==
              ConnectionState.waiting){


            return const Center(

              child:
              CircularProgressIndicator(),

            );


          }





          if(!snapshot.hasData ||
              snapshot.data!.docs.isEmpty){



            return const Center(

              child:

              Text(

                "No notice available",

                style:
                TextStyle(

                  fontSize:18,

                ),

              ),

            );


          }





          var notices =
              snapshot.data!.docs;




          return ListView.builder(



            padding:
            const EdgeInsets.all(20),



            itemCount:
            notices.length,



            itemBuilder:(context,index){



              var data =

              notices[index].data()

              as Map<String,dynamic>;





              return Card(



                margin:
                const EdgeInsets.only(

                  bottom:15,

                ),



                elevation:3,



                shape:

                RoundedRectangleBorder(

                  borderRadius:

                  BorderRadius.circular(15),

                ),




                child:

                ListTile(



                  leading:

                  const CircleAvatar(

                    child:

                    Icon(

                      Icons.notifications,

                    ),

                  ),




                  title:

                  Text(

                    data["title"] ?? "",

                    style:

                    const TextStyle(

                      fontWeight:

                      FontWeight.bold,

                    ),

                  ),





                  subtitle:

                  Column(

                    crossAxisAlignment:

                    CrossAxisAlignment.start,


                    children:[



                      const SizedBox(
                        height:8,
                      ),



                      Text(

                        data["description"] ?? "",

                      ),




                      const SizedBox(
                        height:8,
                      ),




                      Text(

                        "Date: ${data["date"] ?? ""}",

                        style:

                        const TextStyle(

                          color: Colors.grey,

                        ),

                      ),



                    ],


                  ),



                ),



              );


            },


          );



        },

      ),


    );


  }


}