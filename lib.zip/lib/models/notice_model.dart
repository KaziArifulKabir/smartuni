class NoticeModel {


  final String? id;


  final String title;


  final String description;


  final String date;


  final String postedBy;


  final String department;




  NoticeModel({


    this.id,


    required this.title,


    required this.description,


    required this.date,


    required this.postedBy,


    required this.department,


  });





  Map<String,dynamic> toMap(){


    return{


      "title":
      title,


      "description":
      description,


      "date":
      date,


      "postedBy":
      postedBy,


      "department":
      department,


    };


  }




  factory NoticeModel.fromMap(

      Map<String,dynamic> map,

      String id

      ){


    return NoticeModel(


      id:id,


      title:
      map["title"] ?? "",


      description:
      map["description"] ?? "",


      date:
      map["date"] ?? "",


      postedBy:
      map["postedBy"] ?? "",


      department:
      map["department"] ?? "",


    );


  }


}